package com.company.Hashing.Rectangles;

public class Rectangle {
}

package com.company.LinkedList;


public class LinkedClient {


    public static void main(String[] args) {

        LinkedList list1 = new LinkedList();

        list1.insertlast(1);
        list1.insertlast(2);

        list1.insertlast(3);
        list1.insertlast(4);

        list1.insertlast(5);



        list1.kreverse(3);
        list1.display();

//        list1.oddeven();
//
//        list1.display();


//        LinkedList sorted = list1.mergesort(list1);
//
//        sorted.display();

//        System.out.println(list1.kthfromlast(3));

//        System.out.println(list1.mid());

//        LinkedList list2 = new LinkedList();
//
//        list2.insertlast(4);
//
//        list2.insertlast(7);
//        list2.insertlast(9);

//        System.out.println(list.deleteindex(2));
//        list.insertlast(15);
//
//        list.reverse();//        list.insertlast(10);
////
//        list.deletelast();
//
//        list.insertlast(14);

//        System.out.println(list.size);
//        System.out.println(list.deleteindex(0));

//        list.insertfirst(10);
//
//        list.insertfirst(5);
//        list.insertmid(1,8);

//        list.insertmid(3,9);

//        list.insertmid(0,10);

//        System.out.println(list.deletefirst());
//
//        System.out.println(list.deletefirst());

//        LinkedList list = new LinkedList();
//        LinkedList l3 = list1.merge(list1,list2);
//        l3.display();

    }
}

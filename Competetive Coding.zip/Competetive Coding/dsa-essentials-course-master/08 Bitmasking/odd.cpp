#include<iostream>
using namespace std;



int main(){

	int x;
	cin>>x;

	if(x&1){
		cout<<"Odd";
	}
	else{
		cout<<"Even";
	}


	return 0;
}
//Expected Time Complexity :O(N log N)


#include<bits/stdc++.h>
using namespace std;

vector<pair<int, int>> sortCartesian(vector<pair<int, int>> v)
{
    sort(v.begin(), v.end());
    return v;
}